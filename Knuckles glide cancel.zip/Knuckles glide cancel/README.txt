Knuckles Glide cancel.

A pretty simple but helpful mod. It allows Knuckles to cancel his glide and recurl in the air.
The mod contains two types of glide cancel for Knuckles.

Default:
Meant to be similar to the flight cancel tails has, press up while gliding to cancel.

Megmaix mania:
Press ABC while gliding to Cancel the glide.

The mod also contains 3 SFX options for when you glide cancel

Default (none):

No sound effect

The jump SFX:

Also from Megamix mania.

Instashield SFX:
The instashield SFX really fits this move, so i activated ias an option.

The flight cancel works for base knuckles only so it will not overwrite or affect ES characters in any way.
Credits:
BluehotMess- Mod creator

Megamix Mania Team- Optional knuckles glide type. Link for their 2020 SHC submission below.

References:
// Functions obtained from the Sonic 3 Air source code.
sonic3air/Oxygen/sonic3air/scripts/maingame/character/character.lemon

// Sonic Megamix Mania
https://shc.zone/entries/contest2020/274
